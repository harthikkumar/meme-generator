from flask import Flask, render_template, request, send_file
from PIL import Image, ImageDraw, ImageFont
import os
from io import BytesIO

app = Flask(__name__)

# Configure secret key for production
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here')

# Ensure the upload folder exists
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Add error handling
@app.errorhandler(500)
def internal_error(error):
    return "Internal server error", 500

@app.errorhandler(404)
def not_found_error(error):
    return "Page not found", 404

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_meme(image, top_text, bottom_text):
    # Open the image
    img = Image.open(image)
    draw = ImageDraw.Draw(img)
    
    # Calculate font size based on image width
    font_size = int(img.width/15)
    try:
        font = ImageFont.truetype("impact.ttf", font_size)
    except:
        font = ImageFont.load_default()
        
    # Add top text
    top_text = top_text.upper()
    text_width = draw.textlength(top_text, font=font)
    x = (img.width - text_width) / 2
    draw.text((x, 10), top_text, font=font, fill='white', stroke_width=2, stroke_fill='black')
    
    # Add bottom text
    bottom_text = bottom_text.upper()
    text_width = draw.textlength(bottom_text, font=font)
    x = (img.width - text_width) / 2
    y = img.height - font_size - 10
    draw.text((x, y), bottom_text, font=font, fill='white', stroke_width=2, stroke_fill='black')
    
    # Save to BytesIO object
    img_io = BytesIO()
    img.save(img_io, 'PNG')
    img_io.seek(0)
    return img_io

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'image' not in request.files:
            return 'No image uploaded', 400
            
        image = request.files['image']
        top_text = request.form.get('top_text', '')
        bottom_text = request.form.get('bottom_text', '')
        
        if image.filename == '':
            return 'No image selected', 400
            
        if image and allowed_file(image.filename):
            # Generate the meme and return it as a download
            meme = generate_meme(image, top_text, bottom_text)
            return send_file(
                meme,
                mimetype='image/png',
                as_attachment=True,
                download_name='meme.png'
            )
        else:
            return 'Invalid file type', 400
            
    return render_template('index.html')

if __name__ == '__main__':
    # Use environment variables for production
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port) 